import { Component } from '@angular/core';

@Component({
  selector: 'app-devops',
  imports: [],
  templateUrl: './devops.component.html',
  styleUrl: './devops.component.css'
})
export class DevopsComponent {

}

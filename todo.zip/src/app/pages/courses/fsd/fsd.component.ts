import { Component } from '@angular/core';

@Component({
  selector: 'app-fsd',
  imports: [],
  templateUrl: './fsd.component.html',
  styleUrl: './fsd.component.css'
})
export class FsdComponent {

}
